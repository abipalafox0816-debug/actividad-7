<h1>Lista de Superhéroes</h1>
<table border="1">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Nombre Real</th>
            <th>Género</th>
            <th>Universo</th>
        </tr>
    </thead>
    <tbody>
        @foreach($superheroes as $heroe)
            <tr>
                <td>{{ $heroe->id }}</td>
                <td>{{ $heroe->name }}</td>
                <td>{{ $heroe->real_name }}</td>
                <td>{{ $heroe->gender }}</td>
                <td>{{ $heroe->universe_id }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
