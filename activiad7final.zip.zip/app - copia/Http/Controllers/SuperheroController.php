<?php

namespace App\Http\Controllers;

use App\Models\Superhero; // Asegúrate de que esta línea esté aquí
use Illuminate\Http\Request;

class SuperheroController extends Controller
{
    public function index()
    {
        
        $superheroes = Superhero::all(); 

        
        return view('index', compact('superheroes'));
    }
}