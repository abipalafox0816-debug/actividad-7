<h1>Lista de Superhéroes</h1>
<table border="1">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Nombre Real</th>
            <th>Género</th>
            <th>Universo</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $superheroes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heroe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($heroe->id); ?></td>
                <td><?php echo e($heroe->name); ?></td>
                <td><?php echo e($heroe->real_name); ?></td>
                <td><?php echo e($heroe->gender); ?></td>
                <td><?php echo e($heroe->universe_id); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\abiga\Desktop\actividad_7-main\resources\views/index.blade.php ENDPATH**/ ?>