<?php

use Illuminate\Support\Facades\Route;
// Importamos los Modelos y el Controlador
use App\Models\Universe;
use App\Models\Superhero;
use App\Http\Controllers\SuperheroController;

/*
|--------------------------------------------------------------------------
| RUTAS PARA EL CRUD (Actividad 7 y 8)
|--------------------------------------------------------------------------
*/

// 1. Ver la tabla con todos los superhéroes (Read)
Route::get('/superheroes', [SuperheroController::class, 'index']);

// 2. Procesar el formulario para guardar uno nuevo (Create)
Route::post('/superheroes', [SuperheroController::class, 'store']);

// 3. Borrar un superhéroe de la lista (Delete)
Route::delete('/superheroes/{id}', [SuperheroController::class, 'destroy']);


/*
|--------------------------------------------------------------------------
| RUTAS DE PRUEBA (JSON) - Estas las puedes dejar por si las ocupas luego
|--------------------------------------------------------------------------
*/

Route::get('/universes/create', function () {
    $universe = Universe::create([
        'universe' => 'Marvel',
        'company' => 'Marvel',
        'age' => 'modern'
    ]);
    return response()->json(['message' => 'Universe created', 'universe' => $universe]);
});

// Nota: Esta ruta /superheroes/create ahora es diferente a la de la Actividad 8
// pero la dejamos aquí para que no pierdas tus pruebas anteriores.
Route::get('/superheroes/test-create', function () {
    $superhero = Superhero::create([
        'name' => 'Batman',
        'real_name' => 'Bruce Wayne',
        'gender' => 'male',
        'universe_id' => 1
    ]);
    return response()->json(['message' => 'Superhero created', 'superhero' => $superhero]);
});