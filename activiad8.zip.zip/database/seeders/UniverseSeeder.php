<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Universe; // Importante para que funcione

class UniverseSeeder extends Seeder
{
    public function run(): void
    {
        Universe::create(['name' => 'U1', 'company' => 'DC', 'era' => 'Silvery']);
        Universe::create(['name' => 'U2', 'company' => 'DC', 'era' => 'Golden']);
        Universe::create(['name' => 'U3', 'company' => 'DC', 'era' => 'Modern']);
        Universe::create(['name' => 'U4', 'company' => 'Marvel', 'era' => 'Silvery']);
        Universe::create(['name' => 'U5', 'company' => 'Marvel', 'era' => 'Modern']);
    }
}
