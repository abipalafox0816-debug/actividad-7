<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SuperheroSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('superheroes')->insert([
            [
                'name' => 'Spiderman',
                'real_name' => 'Peter Parker',
                'gender' => 'Male',
                'universe_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Wonder Woman',
                'real_name' => 'Diana Prince',
                'gender' => 'Female',
                'universe_id' => 2,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Batman',
                'real_name' => 'Bruce Wayne',
                'gender' => 'Male',
                'universe_id' => 2,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Iron Man',
                'real_name' => 'Tony Stark',
                'gender' => 'Male',
                'universe_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]
        ]);
    }
}