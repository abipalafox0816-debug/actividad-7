<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // El orden importa: Primero los universos, luego los héroes
        $this->call([
            UniverseSeeder::class,
            SuperheroSeeder::class,
        ]);
    }
}
