<?php

namespace App\Http\Controllers;

use App\Models\Superhero;
use Illuminate\Http\Request;

class SuperheroController extends Controller
{
    // Mostrar la tabla (Leer)
    public function index()
    {
        $superheroes = Superhero::with('universe')->get(); 
        return view('index', compact('superheroes'));
    }

    // Guardar nuevo héroe (Crear) - ESTA ES LA NUEVA
    public function store(Request $request)
    {
        // Validamos que los campos no lleguen vacíos
        $request->validate([
            'name' => 'required',
            'real_name' => 'required',
            'universe_id' => 'required'
        ]);

        // Guardamos en la base de datos
        Superhero::create($request->all());

        return redirect('/superheroes')->with('success', 'Héroe creado!');
    }

    // Borrar héroe (Eliminar)
    public function destroy($id)
    {
        $heroe = Superhero::findOrFail($id);
        $heroe->delete();

        return redirect('/superheroes');
    }
}