<?php

namespace App\Http\Controllers;

use App\Models\Universe;
use Illuminate\Http\Request;

class UniverseController extends Controller
{
    public function index()
    {
        // Esto saca los datos de la base de datos actividad_7
        $universes = Universe::all(); 
        
        // Se los manda a tu tabla en la vista
        return view('universes', compact('universes'));
    }
}