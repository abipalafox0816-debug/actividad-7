<div style="margin-bottom: 30px; font-family: sans-serif;">
    <h2>Registrar Nuevo Superhéroe</h2>
    
    <form action="<?php echo e(url('/superheroes')); ?>" method="POST" style="background: #eee; padding: 15px; border-radius: 5px;">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" placeholder="Nombre (Ej: Spiderman)" required>
        
        <input type="text" name="real_name" placeholder="Nombre Real" required>

        <select name="universe_id" required>
            <option value="">-- Selecciona Universo --</option>
            <option value="1">Marvel</option>
            <option value="2">DC</option>
        </select>

        <button type="submit" style="background: green; color: white; border: none; padding: 5px 10px; cursor: pointer;">
            Guardar Héroe
        </button>
    </form>
</div>

<hr>

<h2>Lista de Superhéroes</h2>

<table border="1" style="width: 100%; text-align: left; border-collapse: collapse;">
    <thead>
        <tr style="background-color: #ddd;">
            <th>Nombre</th>
            <th>Universo</th>
            <th>Acciones</th> 
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $superheroes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heroe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($heroe->name); ?></td>
            <td><?php echo e($heroe->universe->name); ?></td>
            <td>
                <form action="<?php echo e(url('/superheroes/'.$heroe->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" style="color:red; cursor: pointer;" onclick="return confirm('¿Seguro?')">
                        Eliminar
                    </button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\Users\abiga\Desktop\actividad_7-main\resources\views/index.blade.php ENDPATH**/ ?>