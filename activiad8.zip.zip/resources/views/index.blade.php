<div style="margin-bottom: 30px; font-family: sans-serif;">
    <h2>Registrar Nuevo Superhéroe</h2>
    
    <form action="{{ url('/superheroes') }}" method="POST" style="background: #eee; padding: 15px; border-radius: 5px;">
        @csrf
        <input type="text" name="name" placeholder="Nombre (Ej: Spiderman)" required>
        
        <input type="text" name="real_name" placeholder="Nombre Real" required>

        <select name="universe_id" required>
            <option value="">-- Selecciona Universo --</option>
            <option value="1">Marvel</option>
            <option value="2">DC</option>
        </select>

        <button type="submit" style="background: green; color: white; border: none; padding: 5px 10px; cursor: pointer;">
            Guardar Héroe
        </button>
    </form>
</div>

<hr>

<h2>Lista de Superhéroes</h2>

<table border="1" style="width: 100%; text-align: left; border-collapse: collapse;">
    <thead>
        <tr style="background-color: #ddd;">
            <th>Nombre</th>
            <th>Universo</th>
            <th>Acciones</th> 
        </tr>
    </thead>
    <tbody>
        @foreach($superheroes as $heroe)
        <tr>
            <td>{{ $heroe->name }}</td>
            <td>{{ $heroe->universe->name }}</td>
            <td>
                <form action="{{ url('/superheroes/'.$heroe->id) }}" method="POST">
                    @csrf
                    @method('DELETE')
                    <button type="submit" style="color:red; cursor: pointer;" onclick="return confirm('¿Seguro?')">
                        Eliminar
                    </button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>